package com.example.practical3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Fragment;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {
FrameLayout fl;
Button add,replace,remove;
int count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fl = findViewById(R.id.framelayout);
        add=findViewById(R.id.button);
        replace = findViewById(R.id.button2);
        remove = findViewById(R.id.button3);
        Fragment1 f1 = new Fragment1();
        Fragment2 f2 = new Fragment2();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    getSupportFragmentManager().beginTransaction().add(R.id.framelayout, f1).commit();

            }
        });
        replace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count++;
                if(count%2==0) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, f1).commit();
                }
                else{
                    getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, f2).commit();
                }
            }
        });
                remove.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if(count%2==0 ){
                            getSupportFragmentManager().beginTransaction().remove(f1).commit();
                        }
                else{
                            getSupportFragmentManager().beginTransaction().remove(f2).commit();
                        }
                    }
                });
    }
}